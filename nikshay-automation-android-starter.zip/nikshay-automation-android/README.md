# Nikshay Automation Assistant — Android starter

This is a starter Android Studio project for a PDF-to-patient-queue workflow. It does **not** log into Nikshay or submit records yet. That integration must be tested against the actual app and approved workflow before any live patient records are changed.

## Current features
- Pick a PDF from Android storage.
- Extract selectable PDF text using PDFBox-Android.
- Parse likely patient names and 9–12 digit IDs into a reviewable queue.
- Show the configured test-entry profile:
  - Reason: TB Screening
  - Predominant symptom: Cough
  - Type of case: New
  - Test type: Chest X Ray
  - State: Maharashtra
  - District: Ahilyanagar
  - Lab: AAM Songaon
  - Date reported: 20/10/2025
  - Final interpretation: Normal
- Keep unspecified fields blank.
- Export parsed patient IDs as CSV.

## Important limitations
- Scanned/image-only PDFs need OCR; this starter currently extracts embedded/selectable PDF text only.
- The ID/name parser is a best-effort starting point and must be checked against a sample PDF.
- Accessibility-based automation is not implemented. Nikshay screen layouts, permissions, app policy and any official integration must be checked first.
- Clinical fields such as symptoms and interpretation must be supported by the patient's record and must not be blindly applied when inaccurate. The configured profile is displayed for review; this starter does not submit clinical data.
- Do not put patient-identifying information into screenshots, logs, analytics, or public repositories.

## Open in Android Studio
1. Extract the ZIP.
2. Open the `nikshay-automation-android` folder in Android Studio.
3. Let Gradle sync.
4. Run on your Android phone or emulator.

Minimum SDK: 26. Android Gradle Plugin and Kotlin versions are specified in the project files.
