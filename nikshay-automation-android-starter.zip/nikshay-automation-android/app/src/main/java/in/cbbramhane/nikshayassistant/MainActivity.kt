package in.cbbramhane.nikshayassistant

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import in.cbbramhane.nikshayassistant.databinding.ActivityMainBinding
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var records: List<PatientRecord> = emptyList()

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            processPdf(uri)
        }
    }

    private val csvCreator = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) writeCsv(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.choosePdfButton.setOnClickListener {
            pdfPicker.launch(arrayOf("application/pdf"))
        }
        binding.exportButton.setOnClickListener {
            csvCreator.launch("nikshay_patient_queue.csv")
        }
    }

    private fun processPdf(uri: Uri) {
        binding.statusText.text = "Reading PDF…"
        binding.fileName.text = uri.lastPathSegment ?: "Selected PDF"

        Thread {
            try {
                val text = contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Unable to open selected PDF." }.use { stream ->
                        PDDocument.load(stream).use { document ->
                            PDFTextStripper().getText(document)
                        }
                    }
                }
                val parsed = parseRecords(text)
                runOnUiThread {
                    records = parsed
                    binding.statusText.text =
                        if (parsed.isEmpty()) {
                            "No likely records found. This PDF may be scanned or formatted differently."
                        } else {
                            "${parsed.size} likely patient record(s) extracted. Verify names and IDs before use."
                        }
                    binding.patientList.text = if (parsed.isEmpty()) {
                        "No records extracted. OCR support or a custom parser may be needed."
                    } else {
                        parsed.mapIndexed { index, p ->
                            "${index + 1}. ${p.name}\n   Nikshay ID: ${p.nikshayId}"
                        }.joinToString("\n\n")
                    }
                    binding.exportButton.isEnabled = parsed.isNotEmpty()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    binding.statusText.text = "Could not read this PDF: ${e.message ?: "unknown error"}"
                    Toast.makeText(this, "PDF reading failed", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /*
     * Heuristic parser for text PDFs. Expected common patterns include:
     * "Patient Name 198410493" or an ID on the same line as a name.
     * This is not a guaranteed parser; inspect results before exporting.
     */
    private fun parseRecords(text: String): List<PatientRecord> {
        val idPattern = Pattern.compile("\\b\\d{9,12}\\b")
        val results = mutableListOf<PatientRecord>()
        val seen = mutableSetOf<String>()

        text.lines().forEach { raw ->
            val line = raw.replace(Regex("\\s+"), " ").trim()
            if (line.isBlank()) return@forEach
            val matcher = idPattern.matcher(line)
            if (!matcher.find()) return@forEach
            val id = matcher.group()
            if (!seen.add(id)) return@forEach

            val before = line.substring(0, matcher.start()).trim(' ', '-', ':', '|', '.', '#')
            val after = line.substring(matcher.end()).trim(' ', '-', ':', '|', '.', '#')
            val candidate = when {
                before.length >= 3 -> before
                after.length >= 3 -> after
                else -> "Name needs review"
            }.take(100)

            // Filter likely headings / date-only lines; keep uncertain names visible for review.
            if (candidate.matches(Regex("(?i)(patient id|nikshay id|id|page \\d+|\\d{1,2}[/.-]\\d{1,2}[/.-]\\d{2,4})"))) {
                return@forEach
            }
            results.add(PatientRecord(candidate, id, line))
        }
        return results
    }

    private fun writeCsv(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { output ->
                BufferedWriter(OutputStreamWriter(output, Charsets.UTF_8)).use { writer ->
                    writer.write("Patient Name,Nikshay ID,Review Status")
                    writer.newLine()
                    records.forEach { record ->
                        writer.write("${csvEscape(record.name)},${csvEscape(record.nikshayId)},Needs review")
                        writer.newLine()
                    }
                }
            }
            Toast.makeText(this, "CSV exported", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun csvEscape(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""
}
