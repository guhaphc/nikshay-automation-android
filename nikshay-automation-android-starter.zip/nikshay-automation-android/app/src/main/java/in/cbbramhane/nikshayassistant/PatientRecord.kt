package in.cbbramhane.nikshayassistant

data class PatientRecord(
    val name: String,
    val nikshayId: String,
    val sourceLine: String
)
